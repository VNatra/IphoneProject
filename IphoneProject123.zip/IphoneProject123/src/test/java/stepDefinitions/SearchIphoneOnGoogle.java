package stepDefinitions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class SearchIphoneOnGoogle {
	
	public WebDriver driver;

	public SearchIphoneOnGoogle()
	{
		driver = Hooks.driver;
	}
	@Given("^Given I am on Google$")
	public void I_Open_Google()
	{
		driver.get("http://www.google.com");
	}
	
	@When("^I search for iPhone X Amazon$")
	public void Search_On_Google()
	{
		 WebElement element = driver.findElement(By.name("q"));
         element.sendKeys("iPhone X Amazon");
         element.submit();
		
	}
	
	@And("^I should select the iPhone$")
	public void Select_iPhone_Link()
	{
		driver.findElement(By.cssSelector(".a-size-medium.s-inline.s-access-title.a-text-normal")).click();
		String productname = driver.findElement(By.cssSelector("#productTitle")).getText();
		String productprice = driver.findElement(By.cssSelector("#priceblock_ourprice")).getText();
		
		System.out.println("Name of the Product:"+productname);
		System.out.println("Product price:" +productprice);
	}
	  
	@Then("^I should see the iPhone price is not greater than \"(.*)\"$")
	public void Verify_Book_Is_Added_To_Cart(String ExpectedPrice)
	{
		String ActualPrice = driver.findElement(By.cssSelector("#priceblock_ourprice")).getText();
		Assert.assertEquals(ActualPrice, "ExceptedPrice");
	}
	
	    
}



